let baseInvestment = 50;
let balance = 70;
let direction = 1;

function updateBalance() {
  const change = (Math.random() * 2 * direction).toFixed(2);
  balance = parseFloat(balance) + parseFloat(change * direction);

  if (balance > 85) direction = -1;
  if (balance < 55) direction = 1;

  const profit = balance - baseInvestment;

  document.getElementById('balance').innerText = `$${balance.toFixed(2)}`;
  document.getElementById('profit').innerText = `${profit >= 0 ? '+' : ''}$${profit.toFixed(2)}`;
}

setInterval(updateBalance, 4000);
updateBalance();